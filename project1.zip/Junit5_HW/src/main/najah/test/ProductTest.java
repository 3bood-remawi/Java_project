package main.najah.test;

import main.najah.code.Product;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Product Tests")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ProductTest {

    Product product;

    @BeforeEach
    void setUp() {
        product = new Product("Cappuccino", 10.0);
        System.out.println(">>> [BeforeEach] Product instance created");
    }

    @AfterEach
    void tearDown() {
        System.out.println(">>> [AfterEach] Product test completed");
    }

    @Test
    @Order(1)
    @DisplayName("Test name and price getters")
    void testBasicProperties() {
        assertAll(
            () -> assertEquals("Cappuccino", product.getName()),
            () -> assertEquals(10.0, product.getPrice(), 0.001)
        );
    }

    @Test
    @Order(2)
    @DisplayName("Apply valid discount and check final price")
    void testValidDiscount() {
        product.applyDiscount(20);
        assertEquals(8.0, product.getFinalPrice(), 0.001);
    }

    @Test
    @Order(3)
    @DisplayName("Invalid discount throws exception")
    void testInvalidDiscount() {
        assertThrows(IllegalArgumentException.class, () -> product.applyDiscount(-5));
        assertThrows(IllegalArgumentException.class, () -> product.applyDiscount(100));
    }

    @Test
    @Order(4)
    @DisplayName("Timeout test for final price calculation")
    @Timeout(1)
    void testTimeout() {
        product.applyDiscount(10);
        assertEquals(9.0, product.getFinalPrice(), 0.001);
    }

    @ParameterizedTest(name = "Discount {1}% on ${0} results in ${2}")
    @CsvSource({
        "100.0, 10, 90.0",
        "50.0, 50, 25.0",
        "30.0, 0, 30.0"
    })
    @Order(5)
    @DisplayName("Parameterized test for discount calculations")
    void testFinalPriceParameterized(double price, double discount, double expected) {
        Product p = new Product("Test", price);
        p.applyDiscount(discount);
        assertEquals(expected, p.getFinalPrice(), 0.001);
    }

    @Test
    @Order(6)
    @DisplayName("Creating product with negative price should throw exception")
    void testNegativePrice() {
        assertThrows(IllegalArgumentException.class, () -> new Product("BadProduct", -1.0));
    }

    @Test
    @Order(7)
    @Disabled("Disabled failing test — expected final price is wrong. Fix expected value to 6.0.")
    @DisplayName("Disabled failing test example")
    void testFailingFinalPrice() {
        product.applyDiscount(40);
        assertEquals(5.0, product.getFinalPrice(), 0.001); // Wrong on purpose
    }
}
