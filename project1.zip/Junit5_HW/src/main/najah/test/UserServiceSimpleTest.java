package main.najah.test;

import main.najah.code.UserService;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

class UserServiceTest {

    UserService service = new UserService();

    @Test
    @DisplayName("Valid email returns true")
    void testValidEmail() {
        assertTrue(service.isValidEmail("user@test.com"));
    }

    @ParameterizedTest
    @ValueSource(strings = {"email@", "noAt.com", "plainaddress", ""})
    @DisplayName("Invalid email formats return false")
    void testInvalidEmails(String input) {
        assertFalse(service.isValidEmail(input));
    }

    @Test
    @DisplayName("Valid admin credentials")
    void testValidAuth() {
        assertTrue(service.authenticate("admin", "1234"));
    }

    @ParameterizedTest
    @CsvSource({
        "admin,wrong", "user,1234", "wrong,wrong"
    })
    @DisplayName("Invalid credentials fail")
    void testInvalidAuth(String user, String pass) {
        assertFalse(service.authenticate(user, pass));
    }

    @Test
    @Timeout(value = 1, unit = TimeUnit.SECONDS)
    @DisplayName("Timeout for login")
    void testLoginTimeout() {
        service.authenticate("admin", "1234");
    }
}
