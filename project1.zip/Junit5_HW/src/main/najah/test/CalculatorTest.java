package main.najah.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.api.parallel.ExecutionMode;

import main.najah.code.Calculator;

@TestMethodOrder(OrderAnnotation.class)
@DisplayName("Calculator Tests")
@Execution(ExecutionMode.CONCURRENT) // Enable parallel execution
public class CalculatorTest {

    Calculator calc;

    @BeforeAll
    static void initAll() {
        System.out.println(">>> [BeforeAll] Starting CalculatorTest...");
    }

    @AfterAll
    static void tearDownAll() {
        System.out.println(">>> [AfterAll] CalculatorTest complete.");
    }

    @BeforeEach
    void setUp() {
        calc = new Calculator();
        System.out.println(">>> [BeforeEach] Calculator created.");
    }

    @AfterEach
    void cleanUp() {
        System.out.println(">>> [AfterEach] Test finished.");
    }

    @Test
    @Order(1)
    @DisplayName("Add multiple positive numbers")
    void testAdditionValid() {
        int result = calc.add(1, 2, 3, 4);
        assertEquals(10, result);
        assertTrue(result > 0);
    }

    @Test
    @Order(2)
    @DisplayName("Add with negative numbers")
    void testAdditionNegative() {
        int result = calc.add(-5, 10, -3);
        assertEquals(2, result);
        assertNotEquals(0, result);
    }

    @ParameterizedTest(name = "Divide {0} / {1} = {2}")
    @CsvSource({
        "10, 2, 5",
        "9, 3, 3",
        "100, 10, 10"
    })
    @Order(3)
    @DisplayName("Division - Valid inputs")
    void testDivisionValid(int a, int b, int expected) {
        assertEquals(expected, calc.divide(a, b));
    }

    @Test
    @Order(4)
    @DisplayName("Division by zero throws exception")
    void testDivisionByZero() {
        assertThrows(ArithmeticException.class, () -> calc.divide(10, 0));
    }

    @Test
    @Order(5)
    @DisplayName("Factorial of 5")
    void testFactorialValid() {
        int result = calc.factorial(5);
        assertEquals(120, result);
        assertTrue(result > 0);
    }

    @Test
    @Order(6)
    @DisplayName("Factorial of 0 should be 1")
    void testFactorialZero() {
        assertEquals(1, calc.factorial(0));
    }

    @Test
    @Order(7)
    @DisplayName("Factorial of negative number throws exception")
    void testFactorialNegative() {
        assertThrows(IllegalArgumentException.class, () -> calc.factorial(-3));
    }

    @Test
    @Order(8)
    @DisplayName("Timeout test for addition")
    @Timeout(1)
    void testAdditionTimeout() {
        assertEquals(15, calc.add(5, 5, 5));
    }

    @Test
    @Order(9)
    @Disabled("Failing test for demonstration – fix expected value")
    @DisplayName("Disabled test: incorrect expected value")
    void testFailingExample() {
        int result = calc.add(2, 2);
        assertEquals(5, result); // Intentionally incorrect
    }
}
