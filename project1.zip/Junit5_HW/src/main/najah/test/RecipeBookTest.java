package main.najah.test;

import main.najah.code.Recipe;
import main.najah.code.RecipeBook;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.api.parallel.ExecutionMode;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

@Execution(ExecutionMode.CONCURRENT)
class RecipeBookTest {

    @Test
    @DisplayName("Add new recipe successfully")
    void testAddRecipe() {
        RecipeBook book = new RecipeBook();
        Recipe r = new Recipe(); r.setName("Mocha");
        assertTrue(book.addRecipe(r));
    }

    @Test
    @DisplayName("Add duplicate recipe fails")
    void testAddDuplicate() {
        RecipeBook book = new RecipeBook();
        Recipe r = new Recipe(); r.setName("Latte");
        book.addRecipe(r);
        assertFalse(book.addRecipe(r));
    }

    @Test
    @DisplayName("Delete existing recipe")
    void testDeleteRecipe() {
        RecipeBook book = new RecipeBook();
        Recipe r = new Recipe(); r.setName("Cappuccino");
        book.addRecipe(r);
        String name = book.deleteRecipe(0);
        assertEquals("Cappuccino", name);
    }

    @Test
    @DisplayName("Edit existing recipe")
    void testEditRecipe() {
        RecipeBook book = new RecipeBook();
        Recipe oldR = new Recipe(); oldR.setName("Old");
        Recipe newR = new Recipe(); newR.setName("New");
        book.addRecipe(oldR);
        String edited = book.editRecipe(0, newR);
        assertEquals("Old", edited);
    }

    @ParameterizedTest
    @ValueSource(ints = {0, 1, 2, 3})
    @DisplayName("Add recipes to all slots")
    void testAddAllSlots(int index) {
        RecipeBook book = new RecipeBook();
        Recipe r = new Recipe(); r.setName("Recipe" + index);
        assertTrue(book.addRecipe(r));
    }

    @Test
    @Timeout(value = 500, unit = TimeUnit.MILLISECONDS)
    @DisplayName("Timeout test for deletion")
    void testTimeout() {
        RecipeBook book = new RecipeBook();
        book.deleteRecipe(1);
    }
}
